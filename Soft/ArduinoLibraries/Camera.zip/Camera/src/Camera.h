#include "Arduino.h"

#ifndef Camera_h 
#define Camera_h 

struct CamBlob
{
  uint8_t type;
  uint8_t dummy;
  uint16_t cx;
  uint16_t cy;
  uint32_t area;
  uint16_t left;
  uint16_t right;
  uint16_t top;
  uint16_t bottom;
};

class Camera
{
  uint8_t cam_id;
  HardwareSerial* serial;
public:
  void init(uint8_t cam_id, uint32_t baud_rate, uint8_t timeout);
  void readBlobs(uint8_t max_blob_n = 5);
  uint8_t readData(uint8_t cam_id, uint8_t addr, uint8_t len, uint8_t* resp);
  CamBlob blob[10];
  uint8_t blobs_count = 255;
};

#endif